﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Restart : MonoBehaviour {

	public void Start_New_Game()
    {
        for (int i = 0; i < DataBase.dead_number; i ++)
        {
            DataBase.cur_numbers_new[i] = 0;
            DataBase.alpha_new[i] = 0;
        }
        DataBase.alpha_zero_new = Mathf.PI/2;
        DataBase.alpha_new[0] = DataBase.alpha_zero_new;
        DataBase.sum_to_get = 10;
        DataBase.cur_step = 0;
        DataBase.cur_score = 0;
        DataBase.new_game = true;
        SceneManager.LoadScene(1);
        

    }
}
