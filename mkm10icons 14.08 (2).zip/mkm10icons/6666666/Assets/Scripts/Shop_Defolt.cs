﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Shop_Defolt : MonoBehaviour {

    // Use this for initialization
    string f_name;
    GameObject but;
    Color novik;
    void Start () {
        f_name = "Canvas/Button (" + DataBase.background_img_cur.ToString() + ")";
        but = GameObject.Find(f_name);
        novik = but.GetComponent<Image>().color;
        but.GetComponent<Image>().color = new Color(novik.r, novik.g, novik.b, 1);
    }
	
	// Update is called once per frame
	void Update () {
        f_name = "Canvas/Button (" + DataBase.background_img_cur.ToString() + ")";
        but = GameObject.Find(f_name);
        novik = but.GetComponent<Image>().color;
        but.GetComponent<Image>().color = new Color(novik.r, novik.g, novik.b, 1);
    }
}
