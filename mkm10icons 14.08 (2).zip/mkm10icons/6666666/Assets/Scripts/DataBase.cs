﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DataBase : MonoBehaviour {
    public static bool F_change(int sta, int cs)
    {
        if (cs == (int)20*Mathf.Pow(1.2f, sta - 10))
        {
            cur_step = 0;
            sum_to_get++;
            
            return true;
        }
        return false;
    } 
    public static void Update_Score(int _typ, int _num)
    {
        if (_typ == 0)
        {
            cur_score += sum_to_get*(_num - 1);
        }
        else if (_typ == 1)
        {
            cur_score += 5 * sum_to_get * (_num - 4);
        }
    }
    public static int sum_to_get = 10; // сколько мы набираем сейчас
    public static int dead_number = 15; // сколько кружочков можно набрать максимум
    public static int[] cur_numbers_new = new int[dead_number]; 
    public static double[] alpha_new = new double[dead_number];
    public static bool new_game = true;
    public static double alpha_zero_new = Mathf.PI/2;
    public static int cur_to_add = 5;
    public static int background_img_cur = 0;
    public static int background_img_numbers = 2;
    public static bool change_number = true;
    public static int cur_step = 0; // сколько раз мы набрали sum_to_get
    public static int cur_score = 0;
    
}
