﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Button_Shop : MonoBehaviour {

    public void Change_Visual(int _buttonnum)
    {
        Color novik;
        DataBase.background_img_cur = _buttonnum;
        Debug.Log(_buttonnum.ToString());
        string f_name;
        GameObject but;
        f_name = "Canvas/Button (" + DataBase.background_img_cur.ToString() + ")";
        but = GameObject.Find(f_name);
        novik = but.GetComponent<Image>().color;
        but.GetComponent<Image>().color = new Color(novik.r, novik.g, novik.b, 1);
        for (int i = 0; i < DataBase.background_img_numbers; i++)
        {
            f_name = "Canvas/Button (" + i.ToString() + ")";
            but = GameObject.Find(f_name);
            novik = but.GetComponent<Image>().color;
            but.GetComponent<Image>().color = new Color(novik.r, novik.g, novik.b, 0);
        }
        DataBase.background_img_cur = _buttonnum;
        f_name = "Canvas/Button (" + _buttonnum.ToString() + ")";
        but = GameObject.Find(f_name);
        novik = but.GetComponent<Image>().color;
        but.GetComponent<Image>().color = new Color(novik.r, novik.g, novik.b, 1);

    }
}
