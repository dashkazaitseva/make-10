﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MouseClick : MonoBehaviour {

    //initialization
    int cur_start = 3,  m_in_line = 5;
    const int x_cent = 240, y_cent = 375;
    float R = 200f;
    double alpha_zero_old = 0;
    Random random = new Random();
    int[] cur_numbers_old = new int[DataBase.dead_number];
    double[] alpha_old = new double[DataBase.dead_number];
    int shif = 0;
    int shif1, shif2;
    GameObject[] cur_circles = new GameObject[DataBase.dead_number];
    Text[] cur_text = new Text[DataBase.dead_number];
    GameObject cur_to_add_circle;
    Text cur_to_add_text;
    public GameObject circle_ex;
    public Text text_ex;
    public Canvas canvasic;
    public Text text_to_add;
    public Text text_cur_score;
    float t_wait = 0.0000005f;
    bool cur_change = false;
    int steps_in_visual = 25;



    //shop part of inizialization
    const int shop_size = 1;
    Color[] sample_color = new Color[shop_size];
    
    

    //end_of_inizialization

    IEnumerator Visual_Change_First()
    {
        Clear_Screen();
        int n = 0;
        for (int i = 0; i < DataBase.dead_number; i++)
        {
            if (DataBase.cur_numbers_new[i] > 0)
            {
                n++;
            }
        }
        double[] d_alpha = new double[DataBase.dead_number];
        for (int i = 1; i < DataBase.dead_number; i++)
        {
            d_alpha[i] = 0;
        }
        for (int i = 1; i < n; i++)
        {
            int i_old = i + shif;
            if (i_old >= n - 1)
            {
                i_old -= n - 1;
            }
            d_alpha[i] = DataBase.alpha_new[i] - alpha_old[i_old];
            while (d_alpha[i] > Mathf.PI)
            {
                d_alpha[i] -= 2 * Mathf.PI;
            }
            while (d_alpha[i] < -1 * Mathf.PI)
            {
                d_alpha[i] += 2 * Mathf.PI;
            }
            DataBase.alpha_new[i] = alpha_old[i_old];
        }
        double dx = R * Mathf.Cos((float)DataBase.alpha_new[0]), dy = R * Mathf.Sin((float)DataBase.alpha_new[0]);
        for (int i = 1; i < n; i++)
        {
            d_alpha[i] /= steps_in_visual;
        }
        dx /= steps_in_visual;
        dy /= steps_in_visual;
        double x_cur = x_cent, y_cur = y_cent;
        for (int i = 0; i < steps_in_visual; i++)
        {
            Clear_Screen();
            for (int j = 1; j < n; j++)
            {
                DataBase.alpha_new[j] += d_alpha[j];
                cur_circles[j] = Instantiate(circle_ex);
                cur_circles[j].transform.position = new Vector3(x_cent + R * Mathf.Cos((float)DataBase.alpha_new[j]), y_cent + R * Mathf.Sin((float)DataBase.alpha_new[j]), 0);
                cur_circles[j].transform.SetParent(canvasic.transform, true);
                cur_text[j] = Instantiate(text_ex);
                cur_text[j].transform.SetParent(canvasic.transform, true);
                cur_text[j].text = DataBase.cur_numbers_new[j].ToString();
                cur_text[j].transform.position = new Vector3(x_cent + R * Mathf.Cos((float)DataBase.alpha_new[j]), y_cent + R * Mathf.Sin((float)DataBase.alpha_new[j]), 0);
            }
            x_cur += dx;
            y_cur += dy;
            cur_to_add_circle = Instantiate(circle_ex);
            cur_to_add_circle.transform.position = new Vector3((float)x_cur, (float)y_cur, 0);
            cur_to_add_circle.transform.SetParent(canvasic.transform, true);
            cur_to_add_text = Instantiate(text_ex);
            cur_to_add_text.transform.SetParent(canvasic.transform, true);
            cur_to_add_text.text = DataBase.cur_numbers_new[0].ToString();
            cur_to_add_text.transform.position = new Vector3((float)x_cur, (float)y_cur, 0);
            yield return new WaitForSeconds(t_wait);
        }
        if (Change_Cur_Sequence_Sum())
        {
            DataBase.cur_step++;
            StartCoroutine("Visual_Change_Second");
        }
        else
        {
            cur_change = false;
            Update_sum_to_get();
            StopCoroutine("Visual_Change_First");
        }
    }

    IEnumerator Visual_Change_Second()
    {
        StopCoroutine("Visual_Change_First");
        Update_Alpha();
        int n_old = 0;
        for (int i = 0; i < DataBase.dead_number; i ++)
        {
            if (cur_numbers_old[i] > 0)
            {
                n_old++;
            }
        }
        double[] d_alpha = new double[DataBase.dead_number];
        for (int i = 0; i < DataBase.dead_number; i ++)
        {
            d_alpha[i] = 0;
        }

        Clear_Screen();
        DataBase.Update_Score(0, shif2 - shif1 + 1);
        text_cur_score.text = DataBase.cur_score.ToString();
        Debug.Log(DataBase.cur_score);
        for (int i = shif1; i <= shif2; i ++)
        {
            d_alpha[i % n_old] = DataBase.alpha_new[0] - alpha_old[i % n_old]; 
        }
        for (int i = shif2 + 1; i <= shif2 + n_old - (shif2 - shif1 + 1); i ++)
        {
            d_alpha[i % n_old] = DataBase.alpha_new[i - shif2] - alpha_old[i % n_old];
        }
        for (int i = 0; i < DataBase.dead_number; i ++)
        {
            while (d_alpha[i] > Mathf.PI)
            {
                d_alpha[i] -= 2 * Mathf.PI;
            }
            while (d_alpha[i] < -1 * Mathf.PI)
            {
                d_alpha[i] += 2 * Mathf.PI;
            }
            d_alpha[i] /= steps_in_visual / 2;
        }
        for (int i = 0; i < steps_in_visual / 2; i ++)
        {
            Clear_Screen();
            for (int j = 0; j < n_old; j ++)
            {
                alpha_old[j] += d_alpha[j];
                cur_circles[j] = Instantiate(circle_ex);
                cur_circles[j].transform.position = new Vector3(x_cent + R * Mathf.Cos((float)alpha_old[j]), y_cent + R * Mathf.Sin((float)alpha_old[j]), 0);
                cur_circles[j].transform.SetParent(canvasic.transform, true);
                cur_text[j] = Instantiate(text_ex);
                cur_text[j].transform.SetParent(canvasic.transform, true);
                cur_text[j].text = cur_numbers_old[j].ToString();
                cur_text[j].transform.position = new Vector3(x_cent + R * Mathf.Cos((float)alpha_old[j]), y_cent + R * Mathf.Sin((float)alpha_old[j]), 0);
            }
            yield return new WaitForSeconds(t_wait);
        }
        if (Change_Cur_In_Line())
        {
            StartCoroutine("Visual_Change_Third");
        }
        else
        {
            cur_change = false;
            Update_sum_to_get();
            StopCoroutine("Visual_Change_Second");
        }
    }

    IEnumerator Visual_Change_Third()
    {
        StopCoroutine("Visual_Change_Second");
        DataBase.Update_Score(1, shif2 - shif1 + 1);
        text_cur_score.text = DataBase.cur_score.ToString();
        float d_a = 1f / steps_in_visual, cur_a = 1;
        bool[] cur = new bool[DataBase.dead_number];
        int n_old = 0;
        for (int i = 0; i < DataBase.dead_number; i ++)
        {
            if (cur_numbers_old[i] > 0)
            {
                n_old++;
            }
        }
        for (int i = 0; i < DataBase.dead_number; i ++)
        {
            cur[i] = false;
        }
        for (int i = shif1; i <= shif2; i ++)
        {
            cur[i % n_old] = true;
        }
        for (int i = 0; i < steps_in_visual; i ++)
        {
            Clear_Screen();
            for (int j = 0; j < n_old; j ++)
            {
                cur_circles[j] = Instantiate(circle_ex);
                cur_circles[j].transform.position = new Vector3(x_cent + R * Mathf.Cos((float)alpha_old[j]), y_cent + R * Mathf.Sin((float)alpha_old[j]), 0);
                cur_circles[j].transform.SetParent(canvasic.transform, true);
                cur_text[j] = Instantiate(text_ex);
                cur_text[j].transform.SetParent(canvasic.transform, true);
                cur_text[j].text = cur_numbers_old[j].ToString();
                cur_text[j].transform.position = new Vector3(x_cent + R * Mathf.Cos((float)alpha_old[j]), y_cent + R * Mathf.Sin((float)alpha_old[j]), 0);
                if (cur[j])
                {
                    Color novik = cur_circles[j].GetComponent<Renderer>().material.color;
                    cur_circles[j].GetComponent<Renderer>().material.color = new Color(novik.r, novik.g, novik.b, cur_a);
                   
                    
                }
            }
            cur_a -= d_a;
            cur_a = Mathf.Max(0, cur_a);
            yield return new WaitForSeconds(t_wait);
            
        }
        int n = Get_N();
        double[] d_alpha = new double[DataBase.dead_number];
        for (int i = shif2 + 1; i <= shif2 + n_old - (shif2 - shif1 + 1); i++)
        {
            d_alpha[i - shif2 - 1] = (DataBase.alpha_new[i - shif2 - 1] - alpha_old[i % n_old]);
            while (d_alpha[i - shif2 - 1] < 0)
            {
                d_alpha[i - shif2 - 1] += 2 * Mathf.PI;
            }
            d_alpha[i - shif2 - 1] /= steps_in_visual;
            DataBase.alpha_new[i - shif2 - 1] = alpha_old[i % n_old]; 
        }
        for (int i = 0; i < steps_in_visual; i ++)
        {
            Clear_Screen();
            for (int j = 0; j < n; j++)
            {
                DataBase.alpha_new[j] += d_alpha[j];
                cur_circles[j] = Instantiate(circle_ex);
                cur_circles[j].transform.position = new Vector3(x_cent + R * Mathf.Cos((float)DataBase.alpha_new[j]), y_cent + R * Mathf.Sin((float)DataBase.alpha_new[j]), 0);
                cur_circles[j].transform.SetParent(canvasic.transform, true);
                cur_text[j] = Instantiate(text_ex);
                cur_text[j].transform.SetParent(canvasic.transform, true);
                cur_text[j].text = DataBase.cur_numbers_new[j].ToString();
                cur_text[j].transform.position = new Vector3(x_cent + R * Mathf.Cos((float)DataBase.alpha_new[j]), y_cent + R * Mathf.Sin((float)DataBase.alpha_new[j]), 0);
            }
            yield return new WaitForSeconds(t_wait);
        }
        Clear_Screen();
        cur_change = false;
        Update_sum_to_get();
        StopCoroutine("Visual_Change_Third");
    }


    
    int Get_N()
    {
        int n = 0;
        for (int i = 0; i < DataBase.dead_number; i ++)
        {
            if (DataBase.cur_numbers_new[i] > 0)
            {
                n++;
            }
        }
        return n;
    }

    //void 
    

    //void для подсчета уголочков
    void Update_Alpha()
    {
        int n = Get_N();
        for (int i = 0; i < DataBase.dead_number; i++)
        {
            DataBase.alpha_new[i] = 0;
        }
        DataBase.alpha_new[0] = DataBase.alpha_zero_new;
        if (n == 0)
        {
            return;
        }
        double alpha = 2 * Mathf.PI / n;
        for (int i = 1; i < DataBase.dead_number; i ++)
        {
            DataBase.alpha_new[i] = DataBase.alpha_new[i - 1] + alpha;
        }
    }

    bool Change_Cur_Sequence_Sum()
    {
        int n = Get_N();
        for (int i = 0; i < n; i ++)
        {
            int j = i, s = 0;
            while (j - i + 1 <= n && s <DataBase.sum_to_get)
            {
                s += DataBase.cur_numbers_new[j % n];
                j++;
            }
            if (s == DataBase.sum_to_get && j - 1 - i + 1 > 1)
            {
                alpha_old = (double[])DataBase.alpha_new.Clone();
                cur_numbers_old = (int[])DataBase.cur_numbers_new.Clone();
                alpha_zero_old = DataBase.alpha_zero_new;
                for (int q = 0; q < DataBase.dead_number; q ++)
                {
                    DataBase.alpha_new[q] = 0;
                    DataBase.cur_numbers_new[q] = 0;
                }
                j--;
                shif1 = i;
                shif2 = j;
                if ((j - i + 1) % 2 != 0)
                {
                    DataBase.alpha_new[0] = alpha_old[(j + i) / 2 % n];
                    DataBase.alpha_zero_new = DataBase.alpha_new[0];
                    DataBase.cur_numbers_new[0] = DataBase.sum_to_get;
                }
                else
                {
                    double alpha_1 = alpha_old[(j + i) / 2 % n], alpha_2 = alpha_old[((j + i) / 2 + 1) % n];
                    alpha_1 = Mathf.Atan2(Mathf.Sin((float)alpha_1), Mathf.Cos((float)alpha_1));
                    alpha_2 = Mathf.Atan2(Mathf.Sin((float)alpha_2), Mathf.Cos((float)alpha_2));
                    if (Mathf.Abs( (float) (alpha_2 - alpha_1)) > Mathf.PI)
                    {
                        DataBase.alpha_new[0] = (alpha_2 + alpha_1 + 2 * Mathf.PI) / 2;
                        DataBase.alpha_zero_new = DataBase.alpha_new[0];
                    }
                    else
                    {
                        DataBase.alpha_new[0] = (alpha_1 + alpha_2) / 2;
                        DataBase.alpha_zero_new = DataBase.alpha_new[0];
                    }
                    DataBase.cur_numbers_new[0] = DataBase.sum_to_get;
                }
                int cnt = n - (j - i + 1);
                int j0 = j + 1, c0 = 1; 
                while (cnt > 0)
                {
                    DataBase.cur_numbers_new[c0] = cur_numbers_old[j0 % n];
                    j0++;
                    cnt--;
                    c0++;
                }
                return true;
                //return false;
            }
        }
        return false;
    }

    bool Change_Cur_In_Line()
    {
        int n = Get_N();
        int i, j;
        i = n;
        while (DataBase.cur_numbers_new[i % n] == DataBase.sum_to_get && i > 0)
        {
            i--;
        }
        while (DataBase.cur_numbers_new[i % n] != DataBase.sum_to_get)
        {
            i++;
        }
        j = i;
        while (DataBase.cur_numbers_new[j % n] == DataBase.sum_to_get && j + 1 - i + 1 <= n + 1)
        {
            j++;
        }
        j--;
        if (j - i + 1 >= m_in_line)
        {
            shif1 = i;
            shif2 = j;
            alpha_old = (double[])DataBase.alpha_new.Clone();
            cur_numbers_old = (int[])DataBase.cur_numbers_new.Clone();
            alpha_zero_old = DataBase.alpha_zero_new;
            DataBase.alpha_zero_new = alpha_old[(j + 1) % n];
            for (int q = 0; q < DataBase.dead_number; q ++)
            {
                DataBase.cur_numbers_new[q] = 0;
                DataBase.alpha_new[q] = 0;
            }
            int cnt = n - (j - i + 1);
            int j0 = j + 1, c0 = 0;
            while (cnt > 0)
            {
                DataBase.cur_numbers_new[c0] = cur_numbers_old[j0 % n];
                j0++;
                cnt--;
                c0++;
            }
            Update_Alpha();
            return true;
            //return false;
        }
        return false;
    }

    //bool для проверки углов
    bool Check_Alpha(int x, double alph)
    {
        double alph1 = Mathf.Atan2(Mathf.Sin((float)alpha_old[x]), Mathf.Cos((float)alpha_old[x])), alph2 = Mathf.Atan2(Mathf.Sin((float)alpha_old[x + 1]), Mathf.Cos((float)alpha_old[x + 1]));
        if (alph1 < 0)
        {
            alph1 += 2 * Mathf.PI;
        }
        if (alph2 < 0)
        {
            alph2 += 2 * Mathf.PI;
        }
        if (alph1 <= alph && alph <= alph2 || alph2 < alph1 && (alph1 <= alph && alph <= 2 * Mathf.PI + alph2 || alph1 <= alph + 2 * Mathf.PI && alph <= alph2))
        {
            return true;
        }
        return false;
    }

    //void для определения куда кидать новый элементик
    void Change_Cur_Sequence()
    {
        float x = Input.mousePosition.x - x_cent, y = Input.mousePosition.y - y_cent;
        double alpha_to_get = Mathf.Atan2(y, x);
        int x_left = 0, n = Get_N();
        alpha_old = (double[])DataBase.alpha_new.Clone();
        cur_numbers_old = (int[])DataBase.cur_numbers_new.Clone();
        alpha_zero_old = DataBase.alpha_zero_new;
        DataBase.alpha_zero_new = alpha_to_get;
        for (int i = 0; i < n; i++)
        {
            DataBase.cur_numbers_new[i] = 0;
            DataBase.alpha_new[i] = 0;
        }
        DataBase.cur_numbers_new[0] = DataBase.cur_to_add;
        DataBase.alpha_new[0] = DataBase.alpha_zero_new;
        if (n == 0)
        {
            return;
        }
        if (alpha_to_get < 0)
        {
            alpha_to_get += 2 * Mathf.PI;
        }
        while (x_left + 1 < n && !(Check_Alpha(x_left, alpha_to_get)))
        {
            x_left++;
        }
        shif = x_left;
        for (int i = 1 + x_left; i < n; i ++)
        {
            DataBase.cur_numbers_new[i - x_left] = cur_numbers_old[i];
        }
        for (int i = 0; i <= x_left; i ++)
        {
            DataBase.cur_numbers_new[n - x_left + i] = cur_numbers_old[i];
        }
    }

    //void для вывода на экранчик текущей ситуации
    private void Print_Cur_Sequence()
    {
        Update_Alpha();
        text_to_add.text = DataBase.sum_to_get.ToString();
        text_cur_score.text = DataBase.cur_score.ToString();
        int n = Get_N();
        if (n == 0)
        {
            Clear_Screen();
            cur_to_add_circle = Instantiate(circle_ex);
            cur_to_add_circle.transform.position = new Vector3(x_cent, y_cent, 0);
            cur_to_add_circle.transform.SetParent(canvasic.transform, true);
            cur_to_add_text = Instantiate(text_ex);
            cur_to_add_text.transform.SetParent(canvasic.transform, true);
            cur_to_add_text.text = DataBase.cur_to_add.ToString();
            cur_to_add_text.transform.position = new Vector3(x_cent, y_cent, 0);
            //вывод для 0
            return;
        }
        if (DataBase.new_game == false)
        {

            Clear_Screen();
        }
        Update_Alpha();
        for (int i = 0; i < n; i++)
        {
            cur_circles[i] = Instantiate(circle_ex);
            cur_circles[i].transform.position = new Vector3(x_cent + R * Mathf.Cos((float)DataBase.alpha_new[i]), y_cent + R * Mathf.Sin((float)DataBase.alpha_new[i]), 0);
            cur_circles[i].transform.SetParent(canvasic.transform, true);
            cur_text[i] = Instantiate(text_ex);
            cur_text[i].transform.SetParent(canvasic.transform, true);
            cur_text[i].text = DataBase.cur_numbers_new[i].ToString();
            cur_text[i].transform.position = new Vector3(x_cent + R * Mathf.Cos((float)DataBase.alpha_new[i]), y_cent + R * Mathf.Sin((float)DataBase.alpha_new[i]), 0);
        }
        cur_to_add_circle = Instantiate(circle_ex);
        cur_to_add_circle.transform.position = new Vector3(x_cent, y_cent, 0);
        cur_to_add_circle.transform.SetParent(canvasic.transform, true);
        cur_to_add_text = Instantiate(text_ex);
        cur_to_add_text.transform.SetParent(canvasic.transform, true);
        cur_to_add_text.text = DataBase.cur_to_add.ToString();
        cur_to_add_text.transform.position = new Vector3(x_cent, y_cent, 0);

    }

    private void Update_sum_to_get()
    {
        bool change_position = DataBase.F_change(DataBase.sum_to_get, DataBase.cur_step);
    }

    //delete everuthing
    void Clear_Screen()
    {
        for (int i = 4; i < canvasic.transform.childCount; i++)
        {
            Destroy(canvasic.transform.GetChild(i).gameObject);
        }

    }

    void Start () {
        if (DataBase.new_game)
        {
            cur_change = true;
            sample_color[0] = Color.white;
            for (int i = 0; i < cur_start; i++)
            {
                DataBase.cur_numbers_new[i] = (int)Mathf.Floor(Random.Range(1, DataBase.sum_to_get));
            }
            while (Change_Cur_Sequence_Sum())//тут надо переписать, потому что есть вероятность постоянно влетать
                                             //в прогрессии, в которых действительно есть сумма
            {
                for (int i = 0; i < cur_start; i++)
                {
                    DataBase.cur_numbers_new[i] = (int)Mathf.Floor(Random.Range(1, DataBase.sum_to_get));
                }
            }
            cur_change = false;
            DataBase.cur_to_add = (int)Mathf.Floor(Random.Range(1, DataBase.sum_to_get));
            DataBase.alpha_zero_new = Mathf.PI / 2;
            Update_Alpha();
            Print_Cur_Sequence();
            DataBase.new_game = false;
        }
	}

	// Update is called once per frame
	void Update () {
        if (!cur_change)
        {
            Print_Cur_Sequence();
            if (Get_N() == DataBase.dead_number)
            {
                Clear_Screen();
                SceneManager.LoadScene(3);
                cur_change = true;
                DataBase.new_game = true;
                
            }
        }
        if (Input.GetMouseButtonDown(0) && !(Input.mousePosition.y >= 800-80)) // game_touch
        {
            Change_Cur_Sequence();
            Update_Alpha();
            DataBase.cur_to_add = (int)Mathf.Floor(Random.Range(1, DataBase.sum_to_get));
            cur_change = true;
            StartCoroutine("Visual_Change_First");
        }
        else if (Input.GetMouseButtonDown(0) && (Input.mousePosition.y >= 800 - 80)) //tap button 
        {
            
        }
	}
}
